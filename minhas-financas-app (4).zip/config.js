// Edite só este arquivo para personalizar o app (mantenha as aspas).
window.MF_CONFIG = {
  pix: "",    // sua chave Pix (CPF, e-mail, telefone ou chave aleatória). Vazio = o botão "Apoie o projeto" fica oculto.
  nome: "",   // seu nome (ou razão social) como responsável pelo app. Aparece na Política de Privacidade e nos Termos.
  email: ""   // e-mail de contato. Aparece no rodapé e nas páginas legais.
};
